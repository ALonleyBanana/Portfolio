package stockPortfolioAppliction;
//IFT210 Timothy Victori 11/29/2023
//TransactionHistory Class
public class TransactionHistory {
    //private declarations
    private String ticker, transDate, transType;
    private double qty;
    //cost Basis of stock (CASH = 1.00)
    private double costBasis;

    //default constructor
    public TransactionHistory() {
        ticker = "UNKNOWN";
        qty = 0.00;
        costBasis = 0.00;
    }
    public TransactionHistory(String t, double q, double cb) {
        ticker = t;
        qty = q;
        costBasis = cb;
    }
    //constructor
    public TransactionHistory(String t, String tt, String td, double q, double cb) {
        ticker = t;
        transDate = td;
        transType = tt;
        qty = q;
        costBasis = cb;
    }
    //cash constructor
    public TransactionHistory(String tt, String td, double q) {
        ticker = "CASH";
        transDate = td;
        transType = tt;
        qty = q;
        costBasis = 1.00;
    }

    //setters
    public void setTicker(String t) {
        ticker = t;
    }
    public void setTransDate(String td) {
        transDate = td;
    }
    public void setTransType(String tt) {
        transType = tt;
        if (tt.equals("Cash") | ticker.equals("CASH")) {
            setCostBasis(1.00);
        }
    }
    public void setQty(double q) {
        qty = q;
    }
    public void setCostBasis(double cb) {
        costBasis = cb;
    }

    //getters
    public String getTicker() {
        return ticker;
    }
    public String getTransDate() {
        return transDate;
    }
    public String getTransType() {
        return transType;
    }
    public double getQty() {
        return qty;
    }
    public double getCostBasis() {
        return costBasis;
    }


}