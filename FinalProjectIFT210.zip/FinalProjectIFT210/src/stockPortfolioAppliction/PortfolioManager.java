package stockPortfolioAppliction;
//IFT210 Timothy Victori 11/29/2023
//Portfolio Manager Class

import java.time.LocalDate;
//Imports
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

public class PortfolioManager {
    //private declarations
    private static ArrayList < TransactionHistory > portfolioList = new ArrayList < TransactionHistory > ();
    static ArrayList < TransactionHistory > tHistory = new ArrayList < TransactionHistory > ();

    //Display the options again
    public static void options() {
        System.out.println("Timothy Victori Brokerage Account");
        System.out.println("0 - Exit");
        System.out.println("1 - Deposit Cash");
        System.out.println("2 - Withdraw Cash");
        System.out.println("3 - Buy Stock");
        System.out.println("4 - Sell Stock");
        System.out.println("5 - Display Transaction History");
        System.out.println("6 - Display Portfolio");
        System.out.println("Enter option (0-6): ");
    }

    //depositCash
    public static void depositCash(double amount) {
        String t = "DEPOSIT";
        double curCash;
        if (amount >= 0) {
            //set history log
            String tDate = LocalDate.now().toString();
            TransactionHistory cur = new TransactionHistory(t, tDate, amount);
            tHistory.add(cur);

            //get current cash
            TransactionHistory a = portfolioList.get(0);

            //preform deposit
            curCash = a.getQty() + amount;
            TransactionHistory fin = new TransactionHistory(t, tDate, curCash);
            portfolioList.set(0, fin);

            System.out.println("Deposit Successful!");
        } else {
            System.out.println("Please enter a non negative number.");
        }

    }

    //widthdrawCash
    public static void withdrawCash(double amount) {
        String tType = "WITHDRAW";
        TransactionHistory hold = portfolioList.get(0);
        double curCash = hold.getQty();
        if (curCash >= amount && amount <= 0) {
            double amt = amount - (2 * amount);
            //set history log
            String tDate = LocalDate.now().toString();
            TransactionHistory cur = new TransactionHistory(tType, tDate, amt);
            tHistory.add(cur);
            //perform withraw
            curCash = curCash - amount;
            TransactionHistory fin = new TransactionHistory("CASH", curCash, 1.00);
            portfolioList.set(0, fin);
            System.out.println("Successful Withdrawl");
        } else if (amount < 0) {
            System.out.println("Please enter a non negative number");
        } else {
            System.out.println("Not enough cash in account!");
        }

    }
    public static int findStock(String stock) {
        int index;
        if (portfolioList.contains(stock)) {

            index = portfolioList.indexOf(stock);
            return index;
        } else {

            return -1;
        }
    }

    public static void buyStock(String ticker, double amount, double cB) {
        String tType = "BUY";

        String tDate = LocalDate.now().toString();
        double neededCash = amount * cB;
        withdrawCash(neededCash);
        int update = findStock(ticker);
        TransactionHistory curStock;
        if (update != -1) {
            curStock = portfolioList.get(update);
            double curCB = curStock.getCostBasis();
            double total = amount * curCB;
            TransactionHistory h = new TransactionHistory(ticker, tType, tDate, amount, cB);
            tHistory.add(h);

        } else {
            curStock = new TransactionHistory(ticker, amount, cB);
            portfolioList.add(curStock);

        }

    }
    public static void sellStock(String ticker, double amount) {
        int update = findStock(ticker);
        String tDate = LocalDate.now().toString();
        if (update == -1) {
            System.out.println("You do not have any stock under that ticker in your portfolio");
        } else {
            TransactionHistory curStock = portfolioList.get(update);
            double cb = curStock.getCostBasis();
            double total = amount * cb;
            if (amount <= curStock.getQty()) {
                double sub = curStock.getQty() - amount;
                double amt = amount - (2 * amount);
                TransactionHistory q = new TransactionHistory(ticker, "SELL", tDate, amt, cb);
                TransactionHistory u = new TransactionHistory(ticker, sub, cb);
                portfolioList.set(update, u);
                depositCash(total);
                tHistory.add(q);
            } else {
                System.out.println("Not enough stock.");
            }

        }
    }
    public static void displayHistory() {

        System.out.println("                Timothy Victori Brokerage Account");
        System.out.println("                ===============================");
        System.out.println("Date            Ticker  Quantity        Cost Basis      Trans Type");
        System.out.println("==================================================================");
        for (int i = 0; i < tHistory.size(); i++) {
            TransactionHistory cur = tHistory.get(i);
            String curTD = cur.getTransDate();
            String curTicker = cur.getTicker();
            double curQty = cur.getQty();
            double curCB = cur.getCostBasis();
            String curType = cur.getTransType();
            System.out.printf("%-15s %-7s %-15.2f %-15.2f %-15s %n", curTD, curTicker, curQty, curCB, curType);

        }

    }
    public static void displayPortfolio() {
        String tDate = LocalDate.now().toString();
        System.out.println("Portfolio as of: " + tDate);
        System.out.println("====================================");
        System.out.println("Ticker  Quantity");
        System.out.println("=================");
        for (int i = 0; i < portfolioList.size(); i++) {
            TransactionHistory cur = portfolioList.get(i);
            String curTicker = cur.getTicker();
            double curQty = cur.getQty();
            System.out.printf("%-7s %-7.2f %n", curTicker, curQty);
        }
    }
    //main
    public static void main(String args[]) {

        PortfolioManager.options();
        TransactionHistory initialCash = new TransactionHistory("CASH", 0.0, 1.00);
        portfolioList.add(initialCash);
        //input scanner
        Scanner s = new Scanner(System.in);

        //input storage
        int input = (int) s.nextInt();
        String ticker;
        double quantity;
        String tType;
        double cost;

        //repeat?
        boolean again = true;
        //outcomes
        while (again) {
            //switch to determine transaction
            switch (input) {
                //exit1
                case 0:
                    System.out.println("bye!");
                    again = false;
                    break;

                    //Deposit Cash	
                case 1:
                    System.out.println("Enter amount of Cash to deposit:");
                    try {
                        quantity = s.nextDouble();
                        depositCash(quantity);
                    } catch (InputMismatchException e) {
                        System.out.println("Please enter a valid decimal number!");
                        s.next();
                    }

                    again = true;
                    System.out.println("Enter a new option number 1-6 to continue or 0 to exit");
                    break;
                    //Widthdraw cash
                case 2:
                    System.out.println("Enter amount of Cash to widthdraw:");
                    try {
                        quantity = s.nextDouble();
                        withdrawCash(quantity);
                    } catch (InputMismatchException e) {
                        System.out.println("Please enter a valid decimal number!");
                        s.next();
                    }
                    again = true;
                    System.out.println("Enter a new option number 1-6 to continue or 0 to exit");
                    break;
                    //Buy Stock
                case 3:
                    System.out.println("Enter ticker code: ");
                    ticker = s.next();
                    try {
                        System.out.println("Enter amount of stock to purchase:");
                        quantity = s.nextDouble();
                        try {
                            System.out.println("Enter cost basis of stock: ");
                            cost = s.nextDouble();
                            buyStock(ticker, quantity, cost);
                        } catch (InputMismatchException e) {
                            System.out.println("Please enter a valid decimal number!");
                            s.next();
                        }
                    } catch (InputMismatchException e) {
                        System.out.println("Please enter a valid decimal number!");
                        s.next();
                    }
                    again = true;
                    System.out.println("Enter a new option number 1-6 to continue or 0 to exit");
                    break;
                    //Sell Stock
                case 4:
                    System.out.println("Enter ticker code: ");
                    ticker = s.next();
                    try {
                        System.out.println("Enter amount of stock to sell:");
                        quantity = s.nextDouble();
                    } catch (InputMismatchException e) {
                        System.out.println("Please enter a valid decimal number!");
                        s.next();
                    }
                    again = true;
                    System.out.println("Enter a new option number 1-6 to continue or 0 to exit");
                    break;
                    //Display Transaction History
                case 5:
                    displayHistory();
                    again = true;
                    System.out.println("Enter a new option number 1-6 to continue or 0 to exit");
                    break;
                    //Display Portfolio
                case 6:
                    displayPortfolio();
                    again = true;

                    break;
                    //Other
                default:
                    System.out.println("Please enter a number between 0 and 6.");
                    PortfolioManager.options();
                    again = true;
                    break;

            }
            input = (int) s.nextInt();

        }
    }

}